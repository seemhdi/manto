# راهنمای استفاده از GitHub Actions برای ساخت APK

این راهنما به شما کمک می‌کند تا با استفاده از GitHub Actions به‌طور خودکار APK بسازید.

---

## 📋 پیش‌نیازها

1. **حساب GitHub** (رایگان)
   - اگر ندارید از https://github.com ثبت‌نام کنید

2. **Git** (اختیاری - می‌توانید از رابط وب GitHub استفاده کنید)

---

## 🚀 مراحل راه‌اندازی

### مرحله 1: ایجاد Repository

#### روش A: از طریق وب (ساده‌تر)

1. به https://github.com بروید و وارد شوید
2. روی **+** در گوشه بالا سمت راست کلیک کنید
3. **New repository** را انتخاب کنید
4. نام repository: `DeviceManager` (یا هر نام دیگری)
5. **Public** یا **Private** را انتخاب کنید
6. **Create repository** را بزنید

#### روش B: از طریق Git

```bash
cd DeviceManager
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/USERNAME/DeviceManager.git
git push -u origin main
```

---

### مرحله 2: آپلود فایل‌ها

#### روش A: از طریق وب (توصیه می‌شود)

1. در صفحه repository خود، روی **Add file** کلیک کنید
2. **Upload files** را انتخاب کنید
3. تمام فایل‌های پوشه `DeviceManager` را بکشید و رها کنید
4. **Commit changes** را بزنید

**نکته:** اگر فایل‌ها زیاد هستند، می‌توانید آن‌ها را به صورت ZIP آپلود کنید و سپس extract کنید.

#### روش B: از طریق Git

```bash
cd DeviceManager
git add .
git commit -m "Add project files"
git push
```

---

### مرحله 3: فعال‌سازی GitHub Actions

1. در repository خود، به تب **Actions** بروید
2. اگر پیامی مبنی بر فعال‌سازی workflows دیدید، روی **I understand my workflows, go ahead and enable them** کلیک کنید
3. Workflow به‌طور خودکار شروع می‌شود!

---

### مرحله 4: دانلود APK

#### روش A: از Artifacts (بعد از هر build)

1. به تب **Actions** بروید
2. روی آخرین workflow run کلیک کنید
3. در قسمت **Artifacts**، فایل `app-debug` را دانلود کنید
4. فایل ZIP را extract کنید
5. فایل `app-debug.apk` را خواهید یافت

#### روش B: از Releases (نسخه‌های رسمی)

1. به تب **Releases** بروید
2. آخرین release را انتخاب کنید
3. فایل `app-debug.apk` را دانلود کنید

---

## 🔄 ساخت مجدد APK

هر بار که تغییری در کد ایجاد کنید و push کنید، GitHub Actions به‌طور خودکار APK جدید می‌سازد.

### روش دستی (بدون تغییر کد):

1. به تب **Actions** بروید
2. از سمت چپ، workflow **Build APK** را انتخاب کنید
3. روی **Run workflow** کلیک کنید
4. **Run workflow** را دوباره بزنید
5. صبر کنید تا build تمام شود (3-5 دقیقه)
6. APK را دانلود کنید

---

## ⏱️ زمان ساخت

- **اولین build:** 5-7 دقیقه
- **Build های بعدی:** 3-5 دقیقه (به خاطر cache)

---

## 📦 محل فایل APK

بعد از build موفق، APK در این مکان‌ها قرار می‌گیرد:

1. **Artifacts** (موقت - 30 روز):
   ```
   Actions > [Workflow Run] > Artifacts > app-debug
   ```

2. **Releases** (دائمی):
   ```
   Releases > [Latest Release] > app-debug.apk
   ```

---

## 🔧 رفع مشکلات

### Build Failed

اگر build با خطا مواجه شد:

1. به تب **Actions** بروید
2. روی workflow run ناموفق کلیک کنید
3. لاگ‌ها را بررسی کنید
4. مشکل را رفع کنید و دوباره push کنید

### Workflow نمی‌بیند

اگر workflow در تب Actions نمایش داده نمی‌شود:

1. مطمئن شوید فایل `.github/workflows/build-apk.yml` آپلود شده
2. مطمئن شوید نام branch شما `main` یا `master` است
3. GitHub Actions را فعال کنید (Settings > Actions > General)

---

## 🎯 نکات مهم

### 1. Private Repository

اگر repository شما Private است، فقط شما می‌توانید APK را دانلود کنید.

### 2. Public Repository

⚠️ **هشدار:** اگر repository شما Public است، همه می‌توانند کد و APK را ببینند!

**توصیه:** از Private repository استفاده کنید.

### 3. GitHub Actions Minutes

GitHub برای حساب‌های رایگان:
- **2000 دقیقه در ماه** برای Public repositories
- **2000 دقیقه در ماه** برای Private repositories

هر build حدود 5 دقیقه طول می‌کشد، پس می‌توانید **400 بار در ماه** build بگیرید!

---

## 📱 نصب APK روی گوشی

1. فایل `app-debug.apk` را دانلود کنید
2. به گوشی منتقل کنید
3. از File Manager باز کنید
4. "Install from Unknown Sources" را فعال کنید
5. نصب کنید

---

## 🔄 به‌روزرسانی کد

اگر می‌خواهید کد را تغییر دهید:

### از طریق وب:

1. به فایل مورد نظر بروید
2. روی آیکون مداد (Edit) کلیک کنید
3. تغییرات را اعمال کنید
4. **Commit changes** را بزنید
5. GitHub Actions به‌طور خودکار APK جدید می‌سازد

### از طریق Git:

```bash
# تغییرات را اعمال کنید
git add .
git commit -m "Update code"
git push
```

---

## 🎉 تمام!

الان شما یک سیستم خودکار برای ساخت APK دارید که:

✅ هر بار که کد را تغییر دهید، APK جدید می‌سازد  
✅ نیاز به Android Studio ندارد  
✅ رایگان است  
✅ در ابر اجرا می‌شود  

**موفق باشید!** 🚀
